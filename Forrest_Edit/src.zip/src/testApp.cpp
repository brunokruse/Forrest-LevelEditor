#include "testApp.h"

//--------------------------------------------------------------
void testApp::setup(){
    
    // fonts
    ofTrueTypeFont::setGlobalDpi(72);
    
	franklinBook12.loadFont("DINNeuzeitGroteskStd-Light.otf", 12, true, true);
	franklinBook12.setLineHeight(18.0f);
	franklinBook12.setLetterSpacing(1.037);

    
    worldPos = ofVec2f(0,0); // for minimap
    editorPos = ofVec2f(0,0);
    loadNewFile(worldPos.x, worldPos.y); // load files and assign to array
    
    showMenu = true;
    currentTile = '1';
}

//--------------------------------------------------------------
void testApp::update(){

}

//--------------------------------------------------------------
void testApp::draw(){
    
    
    // now draw loaded tiles
    for (int y = 0; y < 24; y++) {
        for (int x = 0; x < 40; x++) {
            
            int loc = x + y * 40;

            ofNoFill();

            // check the tile type
            if(TileArray1D[loc] == 0 || TileArray1D[loc] == '0') { ofSetColor(170, 170, 170); } 
            
            else if (TileArray1D[loc] == 1 || TileArray1D[loc] == '1') { ofSetColor(30, 30, 30); } 
            
            else if (TileArray1D[loc] == 2 || TileArray1D[loc] == '2') { ofSetColor(30, 30, 255); }
            
            else if (TileArray1D[loc] == 3 || TileArray1D[loc] == '3') { ofSetColor(255, 30, 30); } 
            
            else if (TileArray1D[loc] == 4 || TileArray1D[loc] == '4') { ofSetColor(60, 60, 60); }

            else if (TileArray1D[loc] == 5 || TileArray1D[loc] == '5') { 
                franklinBook12.drawString("E", x * 32, y* 32);
                ofSetColor(255, 255, 255); 
            }
            
            else if (TileArray1D[loc] == 6 || TileArray1D[loc] == '6') { 
                franklinBook12.drawString("C", x * 32, y* 32);
                ofSetColor(0, 0, 0); 
            }

            if (TileArray1D[loc] > 6 || TileArray1D[loc] > 6) {

                string enemyString = "E" + ofToString(TileArray1D[loc]);
                franklinBook12.drawString(enemyString, x * 32, y* 32);


            }

            ofFill();
            ofRect(x * 32, y* 32, 32, 32);
            
            // grid
            if(showGrid) {
                ofNoFill();
                ofSetColor(30, 255, 255);
                ofRect(x * 32, y* 32, 32, 32);
            }

        }
    }
    
    if (showMenu) {
        // draw menu bar
        ofFill();
        ofEnableAlphaBlending();
        ofSetColor(30, 30, 30, 90);
        ofRect(0, 0, 400, 100);
        ofDisableAlphaBlending();
        
        for (int i = 0; i <= 4; i++) {
            
            ofPushMatrix();
            ofTranslate(120, 0);
            
            if (i == 0 )ofSetColor(170, 170, 170);
            if (i == 1 )ofSetColor(30, 30, 30);
            if (i == 2 )ofSetColor(30, 30, 255);
            if (i == 3 )ofSetColor(255, 30, 30); 
            if (i == 4 )ofSetColor(60, 60, 60); 
            
            
            ofFill();
            ofRect(i * 32 + i * 10, 25, 32, 32);
            ofNoFill();
            ofSetColor(255, 255, 255);
            string tileLbl = ofToString(i);
            franklinBook12.drawString(tileLbl, i * 32 + i * 10, 68);
            
            ofPopMatrix();
        
        }
        
        ofSetColor(255, 255, 255);
        string tilesTxt = "available tiles";
        franklinBook12.drawString(tilesTxt, 120, 20);
        
        // draw minimap
        for (int i = 0; i < kWorldSizeY; i++) {
            for(int j = 0; j < kWorldSizeX; j++) {
                
                ofPushMatrix();
                ofTranslate(20, 20);
                ofNoFill();
                ofSetColor(225, 225, 225);
                ofRect(8*i, 8*j, 8, 8);
                ofFill();
                ofRect(worldPos.x * 8, worldPos.y * 8, 8, 8);
                //cout << i << " , " << j << endl;
                ofPopMatrix();
                
            }
        }
        string posTxt = "(" + ofToString(worldPos.x) + "," + ofToString(worldPos.y) + ")";
        franklinBook12.drawString(posTxt, 20, 70);
    }

    
    
    // draw mouse tiler
    ofEnableAlphaBlending();
    ofFill();

    if(tileMode == "tiles") {
        if (currentTile == '0') {
            ofSetColor(170, 170, 170);
        }
        else if (currentTile == '1') {
            ofSetColor(30, 30, 30);
            
        } else if (currentTile == '2') {
            ofSetColor(30, 30, 255);

        } else if (currentTile == '3') {
           ofSetColor(255, 30, 30); 

        } else if (currentTile == '4') {
            ofSetColor(60, 60, 60); 

        }
        else if (currentTile == '5') { // exit
            ofSetColor(255, 255, 255); 

        }
        else if (currentTile == '6') { // checkpoint
            ofSetColor(0, 0, 0); 

        }
    }
    
    
    int xpos = ofMap(mouseX, 0, ofGetWidth(), 0, 40);
    int ypos = ofMap(mouseY, 0, ofGetHeight(), 0, 24);
    
    editorPos.x = xpos;
    editorPos.y = ypos;
    
    ofRect(xpos * 32, ypos * 32, 32, 32);

    ofDisableAlphaBlending();

}

void testApp::loadNewFile(int x, int y) {
    
    string filename = ofToString(x) + ofToString(y) + ".txt";
    ofBuffer buffer = ofBufferFromFile("lvldata/" + filename); // reading into the buffer
    cout << "loading: " + filename << endl;
    
    
    int lineCounter = 1; // lets keep track!
    
    while(!buffer.isLastLine()) {
        string line = buffer.getNextLine();
        string curLineTxt = line;
        cout << "LINE: " << curLineTxt.size() << " | " << curLineTxt << endl;
        
        lineCounter ++; // our current line for logic
        
        // 1st batch
        if (lineCounter < 25) {
            for (int x = 0; x < curLineTxt.size(); x++) {
                TileArrayV.push_back(curLineTxt[x]);
            }
        }
        
        
        // 2nd batch
        if (lineCounter >= 26  && lineCounter < 50) {
            for (int x=0; x<40; x++) {
                SubtypesArrayV.push_back(curLineTxt[x]);
            }
            
        }
        
        // 3rd batch
        if (lineCounter >= 51  && lineCounter < 75) {
            for (int x=0; x<40; x++) {
                EnemyArrayV.push_back(curLineTxt[x]);
            }
            
        }
        
        if (lineCounter == 75) { powerUpCol = ofToInt(curLineTxt); } //powerUpCol
        if (lineCounter == 76) { powerUpRow = ofToInt(curLineTxt); } //powerUpRow
        if (lineCounter == 77) { powerUpType = ofToInt(curLineTxt); } //powerUpType
        if (lineCounter == 78) { checkPointCol = ofToInt(curLineTxt); } //checkPointCol
        if (lineCounter == 79) { checkPointRow = ofToInt(curLineTxt); } //checkPointRow
        
    }
    
    cout << "TileArrayV: " << TileArrayV.size() << endl;
    cout << "SubtypesArrayV: " << SubtypesArrayV.size() << endl;
    cout << "EnemyArrayV: " << EnemyArrayV.size() << endl;
    
    /*
    for (int w = 0; w < TileArrayV.size(); w++) {
        cout << TileArrayV[w];
        
        if (w % 40 == 0 && w != 0)
            cout << endl;
    }*/

    /*
    for (int w = 0; w < TileArrayV.size(); w++) {
        if (w != 0 && w % 40 == 0)
            cout << endl;
        cout << "SubtypesArrayV: " << SubtypesArrayV[w] << endl;
    }
    for (int w = 0; w < TileArrayV.size(); w++) {
        if (w != 0 && w % 40 == 0)
            cout << endl;
        cout << "EnemyArrayV: " << EnemyArrayV[w] << endl;
    }
    */
    
    /*
    curFileTxt = buffer.getText();
    ofStringReplace(curFileTxt,"\n", "");
    ofStringReplace(curFileTxt,"\r", "");
    
    cout << "cureFileTxt: " << curFileTxt << endl;
    // PARSE TILES
    for (int y = 0; y < 24; y++) {
        for (int x = 0; x < 40; x++) {            
            int loc = x + y * 40;
            cout << curFileTxt[loc];
            TileArray1D[loc] = curFileTxt[loc];
        }
        cout << endl;
    }
    
    cout << "-" << endl;

    // PARSE SUBTYPES
    for (int y = 26; y < 50; y++) {
        for (int x = 0; x < 40; x++) {
            int loc = x + y * 40;
            cout << curFileTxt[loc];
            SubtypesArray1D[loc] = curFileTxt[loc];
        }
        cout << endl;
    }
    
    cout << "-" << endl;

    // PARSE ENEMIES
    for (int y = 52; y < 76; y++) {
        for (int x = 0; x < 40; x++) {
            int loc = x + y * 40;
            cout << curFileTxt[loc];
            EnemyArray1D[loc] = curFileTxt[loc];
        }
        cout << endl;
    }
    
    // PARSE MISC
    for (int y = 77; y < 81; y++) {
        for (int x = 0; x < 1; x++) {
            int loc = x + y * 40;
            cout << curFileTxt[loc];
            EnemyArray1D[loc] = curFileTxt[loc];
        }
        cout << endl;
    }
    */
    
}


void testApp::saveMap(int x, int y) {
    
    string filename = ofToString(x) + ofToString(y) + ".txt";
    //ofBuffer buffer = ofBufferFromFile("lvldata/" + filename); // reading into the buffer
    cout << "saving: " + filename << endl;
    
    string writeToText;
    
    for (int x = 0; x < 960; x++) {            
        
        if (x % 40 == 0 && x != 0)
            writeToText += "\n";
        

        writeToText += char(TileArray1D[x]);
    }

    cout << "write to text: " << writeToText<<endl;
    
    //curFileTxt =  TileArray1D;
    
    //string write1DArray = ofToString(TileArray1D);
    
    ofBuffer dataBuffer;
    dataBuffer.set(writeToText.c_str(), writeToText.size());

    
    bool fileWritten = ofBufferToFile("lvldata/" + filename, dataBuffer); 

    
    
    /*
    curFileTxt = buffer.getText();
    ofStringReplace(curFileTxt,"\n", "");
    ofStringReplace(curFileTxt,"\r", "");
    
    // parse file into array
    for (int y = 0; y < 24; y++) {
        for (int x = 0; x < 40; x++) {
            
            int loc = x + y * 40;
            cout << curFileTxt[loc];
            //TileArray2D[x][y] = curFileTxt[loc]; // let's see what it says
            TileArray1D[loc] = curFileTxt[loc];
            
        }
        cout << endl;
    }
    */
    
}


//--------------------------------------------------------------
void testApp::keyPressed(int key){
    
    cout << "keypressed: " << key << endl;
    
    // UPDATE CURRENT TILE
    if (tileMode == "tiles") {
        if (key == '0'){
            currentTile = '0';
        }
        if (key == '1'){
            currentTile = '1';
        }
        if (key == '2'){
            currentTile = '2';
        }
        if (key == '3'){
            currentTile = '3';
        }
        if (key == '4'){
            currentTile = '4';
        }
        if (key == '5'){
            currentTile = '5'; // exit
        }
    
    } else if (tileMode == "enemies") {
        
        // 9 total
        if (key == '0'){
            currentTile = 'a'; // enemy 1
        }
        if (key == '1'){
            currentTile = 'b';
        }
        if (key == '2'){
            currentTile = 'c';
        }
        if (key == '3'){
            currentTile = 'd';
        }
        if (key == '4'){
            currentTile = 'e';
        }
        if (key == '5'){
            currentTile = 'f';
        }
        if (key == '6'){
            currentTile = 'g';
        }
        if (key == '7'){
            currentTile = 'h';
        }
        if (key == '8'){
            currentTile = 'i';
        }
        if (key == '9'){
            currentTile = 'j'; // enemy 9
        }
    
    } else if (tileMode == "checkpoints") {
        currentTile = '6'; // checkpoint
    }
    
    
    // UPDATE TILE MODE
    if (key == 't'){
        tileMode = "tiles";
    }

    if (key == 'e'){
        tileMode = "enemies";
    }

    if (key == 'c'){
        tileMode = "checkpoints";
    }

    
    // EDITOR CONTROLS/INTERFACE
    if (key == 'f'){
        ofToggleFullscreen();
    }

    if (key == 'm'){
        showMenu = !showMenu;
    }
    
    if (key == 'o'){
        saveMap(worldPos.x, worldPos.y);
    }
    
    if (key == 'g'){
        showGrid = !showGrid;
    }
    
    
    // MINIMAP
    if (key == 'w' || key == 357) { // UP
        cout << "up" << endl;
        worldPos.y -= 1;
        if (worldPos.y <= 0) worldPos.y = 0;
        if (worldPos.y >= 4) worldPos.y = 4;
        loadNewFile(worldPos.x, worldPos.y);
    }
    
    if (key == 's' || key == 359) { // DOWN
        cout << "down" << endl;
        worldPos.y += 1;
        if (worldPos.y <= 0) worldPos.y =0;
        if (worldPos.y >= 4) worldPos.y = 4;
        loadNewFile(worldPos.x, worldPos.y);
    }
    
    if (key == 'a' || key == 356) { // LEFT
        cout << "left" << endl;
        worldPos.x -= 1;
        if (worldPos.x <= 0) worldPos.x =0;
        if (worldPos.x >= 4) worldPos.x = 4;
        loadNewFile(worldPos.x, worldPos.y);
    }
    
    if (key == 'd' || key == 358) { // RIGHT
        cout << "right" << endl;
        worldPos.x += 1;
        if (worldPos.x <= 0) worldPos.x =0;        
        if (worldPos.x >= 4) worldPos.x = 4;        
        loadNewFile(worldPos.x, worldPos.y);
        
    }
}

//--------------------------------------------------------------
void testApp::keyReleased(int key){

}

//--------------------------------------------------------------
void testApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void testApp::mouseDragged(int x, int y, int button){
    
    int loc = editorPos.x + editorPos.y * 40;
    cout << button << endl;
    
    if (button == 0) {
        TileArray1D[loc] = int(currentTile);
    } else if(button == 2) {
        
        TileArray1D[loc] = 0;
    }
    
    
}

//--------------------------------------------------------------
void testApp::mousePressed(int x, int y, int button){
    
    int loc = editorPos.x + editorPos.y * 40;
    cout << button << endl;
    
    if (button == 0) {
        TileArray1D[loc] = int(currentTile);
    } else if(button == 2) {
        
        TileArray1D[loc] = 0;
    }
    

}

//--------------------------------------------------------------
void testApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void testApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void testApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void testApp::dragEvent(ofDragInfo dragInfo){ 

}